<?
$module_id = 'citfact.edutemplate';
require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/'.$module_id.'/include.php');
?>
<?
CModule::AddAutoloadClasses(
    "citfact.registeruser",
    array(
        "CModuleEdutemplate" => "classes/general/citfact_classes.php",
    )
);  
?>

<?
$MESS["NEWS_TYPE_NAME"] = "News";
$MESS["NEWS_ELEMENT_NAME"] = "News";
$MESS["NEWS_SECTION_NAME"] = "Bereiche";
$MESS["PRODUCTS_TYPE_NAME"] = "Produkte und Dienstleistungen ";
$MESS["PRODUCTS_ELEMENT_NAME"] = "Produkte und Dienstleistungen ";
$MESS["PRODUCTS_SECTION_NAME"] = "Bereiche";
?>
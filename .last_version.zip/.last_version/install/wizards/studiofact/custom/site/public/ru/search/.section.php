<?
$sSectionName = "Поиск";
$arDirProperties = Array(

);
?>
<?
define("BX_SKIP_SESSION_EXPAND", true);
define("PUBLIC_AJAX_MODE", true);
define("NO_KEEP_STATISTIC", "Y");
define("NO_AGENT_STATISTIC","Y");
define("NO_AGENT_CHECK", true);
define("BX_SKIP_TIMEZONE_COOKIE", true);
define("DisableEventsCheck", true);
?>
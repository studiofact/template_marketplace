<?$arTemplate = array(
	"NAME" => GetMessage("SITE_TEMPLATE_STUDIOFACT"),
	"DESCRIPTION" => GetMessage("SITE_TEMPLATE_STUDIOFACT_DESC"),
	"SORT" => "",
);
?>
<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arTemplateDescription = array(
	"NAME" => GetMessage("MENU_DOT_DEFAULT_NAME"),
	"DESCRIPTION" => GetMessage("MENU_DOT_DEFAULT_DESC"),
);
?>
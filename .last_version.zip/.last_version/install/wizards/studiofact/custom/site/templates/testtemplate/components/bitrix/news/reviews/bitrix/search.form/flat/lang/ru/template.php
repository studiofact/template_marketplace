<?
$MESS ['BSF_T_SEARCH_BUTTON'] = "Поиск";
?>